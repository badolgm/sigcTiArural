🌾 SIGC&T Rural
<div align="center">
Mostrar imagen
Sistema Integrado de Gestión del Conocimiento y Tecnología Rural
Plataforma web híbrida (Cloud/Edge) que integra IoT, Inteligencia Artificial y educación técnica para impulsar la agricultura sostenible y la inclusión tecnológica en zonas rurales de Colombia.

Mostrar imagen
Mostrar imagen
Mostrar imagen
Mostrar imagen
Mostrar imagen
Mostrar imagen
Mostrar imagen
Mostrar imagen
Mostrar imagen
Mostrar imagen
🚀 Demo en Vivo • 📚 Documentación • 🎯 Plan Maestro • 🐛 Reportar Bug • 💡 Solicitar Feature
</div>

📖 Tabla de Contenidos

🎯 ¿Qué es SIGC&T Rural?
✨ Características Principales
🏗️ Arquitectura del Sistema
🎥 Demo Visual
🚀 Inicio Rápido
📦 Instalación Completa
🔧 Configuración
🧪 Uso y Ejemplos
📊 Stack Tecnológico
🤖 Inteligencia Artificial
🌐 API REST
🧩 Estructura del Proyecto
🧪 Testing
🚢 Despliegue
🤝 Contribuciones
📄 Documentación
🎓 Contexto Académico
📜 Licencia
👥 Autores
🙏 Agradecimientos


🎯 ¿Qué es SIGC&T Rural?
SIGC&T Rural es una plataforma web de código abierto diseñada para revolucionar la agricultura mediante la integración de tecnologías emergentes:
🌟 Misión
Democratizar el acceso a tecnologías de agricultura inteligente en zonas rurales de Colombia, proporcionando herramientas de monitoreo IoT, diagnóstico con IA y educación técnica gratuita.
🎯 Objetivos
<table>
<tr>
<td width="50%">
🌱 Para Agricultores

Monitoreo en tiempo real de cultivos
Alertas tempranas de enfermedades (IA)
Optimización de recursos (riego, fertilizantes)
Dashboard accesible desde cualquier dispositivo

</td>
<td width="50%">
🎓 Para Estudiantes SENA

Biblioteca de recursos educativos curados
Laboratorios virtuales interactivos
Casos de estudio reales de IoT y IA
Formación práctica en tecnologías modernas

</td>
</tr>
</table>
🌍 Impacto Social
El proyecto se alinea con los Objetivos de Desarrollo Sostenible (ODS) de la ONU:

ODS 2 - Hambre Cero: Aumenta productividad agrícola mediante tecnología
ODS 4 - Educación de Calidad: Acceso gratuito a formación técnica
ODS 9 - Industria e Innovación: Infraestructura tecnológica rural
ODS 17 - Alianzas: Colaboración academia-agricultura


✨ Características Principales
🔥 Funcionalidades Core
<table>
<tr>
<td width="33%" align="center">
📊 Dashboard IoT
Mostrar imagen
Visualización en tiempo real de:

🌡️ Temperatura
💧 Humedad ambiental y del suelo
☀️ Luminosidad
📸 Capturas de cultivo

</td>
<td width="33%" align="center">
🤖 Diagnóstico IA
Mostrar imagen
Clasificación automática de:

✅ Plantas sanas
🍂 38 tipos de enfermedades
🎯 Confianza >85%
⚡ Inferencia Cloud + Edge

</td>
<td width="33%" align="center">
📚 Biblioteca Educativa
Mostrar imagen
Contenido curado sobre:

🔧 IoT y Sistemas Embebidos
🧠 Inteligencia Artificial
🌾 Agricultura 4.0
📡 Telecomunicaciones

</td>
</tr>
</table>
🚀 Innovaciones Técnicas

Arquitectura Híbrida Cloud-Edge: Procesamiento distribuido para máxima eficiencia
Inferencia IA en Edge: Latencia <500ms con TensorFlow Lite en BeagleBone Black
WebSockets: Actualizaciones del dashboard sin refrescar página
API RESTful: Integración fácil con sistemas externos
Responsive Design: Funciona en móvil, tablet y desktop
Open Source: Código 100% abierto bajo licencia MIT


🏗️ Arquitectura del Sistema
Vista de Alto Nivel
mermaidgraph TB
    subgraph "☁️ CLOUD (Render/Railway)"
        Frontend[⚛️ React App<br/>TailwindCSS]
        Backend[🐍 Django API<br/>DRF + Channels]
        Database[(💾 PostgreSQL<br/>+ PostGIS)]
        AICloud[🤖 IA Service<br/>TensorFlow]
    end
    
    subgraph "🏠 EDGE (Laboratorio Físico)"
        BBB1[🌐 BBB-01<br/>Gateway MQTT]
        BBB2[🧠 BBB-02<br/>IA TFLite]
        BBB3[📡 BBB-03<br/>Sensores IoT]
    end
    
    Users[👥 Usuarios<br/>Web/Móvil] --> Frontend
    Frontend <--> Backend
    Backend <--> Database
    Backend <--> AICloud
    
    BBB3 -->|MQTT| BBB1
    BBB3 -->|HTTP| BBB2
    BBB1 -->|HTTPS| Backend
    BBB2 -.->|Alertas| BBB1
    
    style Frontend fill:#61dafb
    style Backend fill:#0c4b33
    style Database fill:#336791
    style AICloud fill:#ff6f00
    style BBB1 fill:#ffa500
    style BBB2 fill:#ff4444
    style BBB3 fill:#4444ff
Modelo C4 - Vista de Contenedores
Para visualizar la arquitectura completa con diagramas detallados C4, consulta:
📘 MASTERDOC.md - Documento de Arquitectura de Software

🎥 Demo Visual
Screenshots del Sistema
<table>
<tr>
<td width="50%">
📊 Dashboard Principal
Mostrar imagen
Monitoreo en tiempo real de sensores con gráficos interactivos
</td>
<td width="50%">
🤖 Laboratorio de IA
Mostrar imagen
Diagnóstico instantáneo de enfermedades en plantas
</td>
</tr>
<tr>
<td width="50%">
📚 Biblioteca Educativa
Mostrar imagen
Cursos, videos y laboratorios virtuales gratuitos
</td>
<td width="50%">
🖥️ Clúster Edge
Mostrar imagen
Hardware embebido en laboratorio físico
</td>
</tr>
</table>

📹 Video Demo Completo: Ver en YouTube (Próximamente)


🚀 Inicio Rápido
Requisitos Previos

Docker 20+ y Docker Compose 2+
Git 2.30+
Node.js 18+ y npm 9+ (solo para desarrollo local sin Docker)
Python 3.10+ (solo para desarrollo local sin Docker)

⚡ Instalación Rápida con Docker (Recomendado)
bash# 1. Clonar el repositorio
git clone https://github.com/badolgm/sigcTiArural.git
cd sigcTiArural

# 2. Copiar variables de entorno
cp config/.env.example config/.env

# 3. Editar .env con tus credenciales
nano config/.env

# 4. Levantar todos los servicios
docker-compose up -d

# 5. Ejecutar migraciones
docker-compose exec backend python manage.py migrate

# 6. Crear superusuario
docker-compose exec backend python manage.py createsuperuser

# 7. Cargar datos de ejemplo (opcional)
docker-compose exec backend python manage.py loaddata fixtures/initial_data.json
🎉 ¡Listo! Accede a:

Frontend: http://localhost:3000
Backend API: http://localhost:8000/api/
Django Admin: http://localhost:8000/admin/


📦 Instalación Completa
Opción 1: Desarrollo Local (Sin Docker)
Backend (Django)
bash# Navegar al directorio backend
cd src/backend/

# Crear entorno virtual
python -m venv venv

# Activar entorno virtual
# En Linux/Mac:
source venv/bin/activate
# En Windows:
venv\Scripts\activate

# Instalar dependencias
pip install -r requirements.txt

# Configurar base de datos PostgreSQL
# Editar src/backend/sigct_backend/settings.py con tus credenciales

# Ejecutar migraciones
python manage.py makemigrations
python manage.py migrate

# Crear superusuario
python manage.py createsuperuser

# Ejecutar servidor de desarrollo
python manage.py runserver 0.0.0.0:8000
Frontend (React)
bash# En otra terminal, navegar al directorio frontend
cd src/frontend/

# Instalar dependencias
npm install

# Configurar API URL
echo "VITE_API_URL=http://localhost:8000" > .env.local

# Ejecutar servidor de desarrollo
npm run dev

# La app estará disponible en http://localhost:5173
Opción 2: Configuración de BeagleBone Black (Edge)
Requisitos de Hardware

3x BeagleBone Black Rev C
Sensor DHT22 (temperatura + humedad)
Sensor de humedad de suelo (analógico)
Cámara USB (resolución mínima 640x480)
Switch/Router para red local
Cables Ethernet, Jumper wires

Configuración de BBB-01 (Gateway)
bash# SSH a la BeagleBone
ssh debian@192.168.1.100

# Actualizar sistema
sudo apt update && sudo apt upgrade -y

# Instalar Mosquitto (Broker MQTT)
sudo apt install mosquitto mosquitto-clients -y

# Instalar dependencias Python
sudo pip3 install paho-mqtt requests pyyaml

# Clonar código del proyecto
cd /opt/
sudo git clone https://github.com/badolgm/sigcTiArural.git

# Copiar script y configuración
cd sigcTiArural/src/embedded/bbb_01_gateway/
sudo cp config.yaml.example config.yaml
sudo nano config.yaml  # Editar con API key del Cloud

# Crear servicio systemd
sudo cp systemd/mqtt-gateway.service /etc/systemd/system/
sudo systemctl enable mqtt-gateway.service
sudo systemctl start mqtt-gateway.service

# Verificar estado
sudo systemctl status mqtt-gateway.service

📘 Guía completa de configuración Edge: docs/EDGE_SETUP.md


🔧 Configuración
Variables de Entorno
Crea un archivo config/.env con las siguientes variables:
bash# ======================
# BACKEND (Django)
# ======================
DEBUG=True
SECRET_KEY=tu-secret-key-super-segura-aqui
ALLOWED_HOSTS=localhost,127.0.0.1,sigct-rural.com

# Database
DB_ENGINE=django.contrib.gis.db.backends.postgis
DB_NAME=sigct_rural_db
DB_USER=sigct_user
DB_PASSWORD=tu-password-segura
DB_HOST=localhost
DB_PORT=5432

# Email (para alertas)
EMAIL_BACKEND=django.core.mail.backends.smtp.EmailBackend
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USE_TLS=True
EMAIL_HOST_USER=tu-email@gmail.com
EMAIL_HOST_PASSWORD=tu-app-password

# JWT
JWT_SECRET_KEY=otra-key-diferente
JWT_ALGORITHM=HS256
JWT_EXPIRATION_DELTA=3600

# ======================
# FRONTEND (React)
# ======================
VITE_API_URL=http://localhost:8000
VITE_WS_URL=ws://localhost:8000/ws

# ======================
# EDGE (BeagleBone)
# ======================
CLOUD_API_URL=https://api.sigct-rural.com
CLOUD_API_KEY=api-key-generada-en-django-admin
MQTT_BROKER_IP=192.168.1.100
MQTT_BROKER_PORT=1883

# ======================
# AI MODEL
# ======================
MODEL_PATH_CLOUD=src/ai_models/production_models/model_v1.h5
MODEL_PATH_EDGE=src/ai_models/production_models/model_v1.tflite
LABELS_PATH=src/ai_models/production_models/labels.txt
Configuración de PostgreSQL
bash# Instalar PostgreSQL y PostGIS
sudo apt install postgresql postgresql-contrib postgis -y

# Acceder a PostgreSQL
sudo -u postgres psql

# Crear base de datos y usuario
CREATE DATABASE sigct_rural_db;
CREATE USER sigct_user WITH PASSWORD 'tu-password-segura';
ALTER ROLE sigct_user SET client_encoding TO 'utf8';
ALTER ROLE sigct_user SET default_transaction_isolation TO 'read committed';
ALTER ROLE sigct_user SET timezone TO 'UTC';
GRANT ALL PRIVILEGES ON DATABASE sigct_rural_db TO sigct_user;

# Habilitar PostGIS
\c sigct_rural_db
CREATE EXTENSION postgis;

# Salir
\q

🧪 Uso y Ejemplos
Caso de Uso 1: Monitorear Temperatura en Tiempo Real
python# Script Python para leer sensor DHT22 (BBB-03)
import Adafruit_DHT
import paho.mqtt.client as mqtt
import json
from datetime import datetime

DHT_SENSOR = Adafruit_DHT.DHT22
DHT_PIN = "P8_11"

client = mqtt.Client()
client.connect("192.168.1.100", 1883, 60)

while True:
    humidity, temperature = Adafruit_DHT.read_retry(DHT_SENSOR, DHT_PIN)
    
    if humidity and temperature:
        payload = {
            "nodo_id": "BBB-03",
            "sensor_tipo": "temperatura",
            "valor": round(temperature, 2),
            "timestamp": datetime.utcnow().isoformat()
        }
        
        client.publish("sigct/sensors/bbb03/temperatura", json.dumps(payload))
        print(f"✅ Publicado: {temperature}°C")
    
    time.sleep(10)
Caso de Uso 2: Clasificar Enfermedad con IA
javascript// Frontend React - Subir imagen al modelo de IA
import { useState } from 'react';
import { api } from './services/api';

function IAClassifier() {
  const [image, setImage] = useState(null);
  const [result, setResult] = useState(null);

  const handleAnalyze = async () => {
    const formData = new FormData();
    formData.append('image', image);
    
    try {
      const response = await api.post('/api/ia/classify/', formData);
      setResult(response.data);
      console.log(`Predicción: ${response.data.prediccion}`);
      console.log(`Confianza: ${(response.data.confianza * 100).toFixed(1)}%`);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  return (
    <div>
      <input type="file" onChange={(e) => setImage(e.target.files[0])} />
      <button onClick={handleAnalyze}>Analizar con IA</button>
      {result && (
        <div>
          <h3>{result.prediccion}</h3>
          <p>Confianza: {(result.confianza * 100).toFixed(1)}%</p>
        </div>
      )}
    </div>
  );
}
Caso de Uso 3: Consumir API REST
bash# Obtener últimas lecturas de un proyecto
curl -X GET "https://api.sigct-rural.com/api/v1/latest-readings/uuid-proyecto/" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"

# Respuesta JSON
{
  "temperatura": {
    "valor": 24.5,
    "unidad": "°C",
    "timestamp": "2025-11-02T14:30:00Z"
  },
  "humedad": {
    "valor": 65.2,
    "unidad": "%",
    "timestamp": "2025-11-02T14:30:00Z"
  }
}

📊 Stack Tecnológico
Backend
TecnologíaVersiónPropósitoPython3.10+Lenguaje principalDjango4.2+Framework webDjango REST Framework3.14+API RESTfulDjango Channels4.0+WebSocketsPostgreSQL15+Base de datosPostGIS3.3+Extensión geoespacialCelery5.3+Tareas asíncronasRedis7.0+Cache y message brokerGunicorn20+WSGI server
Frontend
TecnologíaVersiónPropósitoReact18+Framework UIVite5+Build toolTailwindCSS3+Framework CSSAxios1.6+HTTP clientRecharts2.10+GráficosReact Router6+Enrutamiento
Inteligencia Artificial
TecnologíaVersiónPropósitoTensorFlow2.15+Framework ML (Cloud)TensorFlow Lite2.15+ML en EdgeKeras2.15+High-level APIOpenCV4.8+Procesamiento de imágenesNumPy1.26+Computación numéricaPandas2.1+Análisis de datos
Edge Computing
TecnologíaVersiónPropósitoBeagleBone BlackRev CHardware embebidoDebian11Sistema operativoPaho-MQTT1.6+Cliente MQTTFlask3.0+API ligera (IA Edge)Adafruit_BBIO1.2+Control GPIOMosquitto2.0+Broker MQTT
DevOps
TecnologíaPropósitoDockerContenedorizaciónDocker ComposeOrquestación localGitHub ActionsCI/CDRenderHosting CloudNginxReverse proxy

🤖 Inteligencia Artificial
Modelo de Clasificación de Enfermedades
Arquitectura: MobileNetV2 con Transfer Learning
python# Resumen del modelo
Input: (224, 224, 3)
    ↓
MobileNetV2 Base (ImageNet pre-trained)
    ↓
GlobalAveragePooling2D
    ↓
Dropout(0.3)
    ↓
Dense(38, activation='softmax')
    ↓
Output: Probabilidades de 38 clases
Dataset: PlantVillage

Total de imágenes: 54,305
Clases: 38 (enfermedades de tomate, papa, pimiento)
Split: 80% train, 10% validation, 10% test
Data Augmentation: Rotación, zoom, flip, contrast

Métricas de Rendimiento
MétricaCloud (model.h5)Edge (model.tflite)Accuracy92.3%88.1%Precision91.8%87.5%Recall91.5%87.2%F1-Score91.6%87.3%Tamaño del modelo14 MB3.8 MBLatencia (inferencia)2-5s<500ms
Entrenamiento
bash# Ejecutar notebook de entrenamiento
cd src/ai_models/notebooks/
jupyter notebook 02_Training.ipynb

# O ejecutar script directo
python src/ai_models/scripts/train.py \
  --dataset data/datasets/plantvillage/ \
  --epochs 50 \
  --batch-size 32 \
  --model-output production_models/model_v1.h5

# Convertir a TensorFlow Lite
python src/ai_models/scripts/convert_tflite.py \
  --input production_models/model_v1.h5 \
  --output production_models/model_v1.tflite

🌐 API REST
Endpoints Principales
Autenticación
httpPOST /api/auth/register/
POST /api/auth/login/
POST /api/auth/refresh/
GET  /api/auth/me/
Proyectos
httpGET    /api/v1/proyectos/
POST   /api/v1/proyectos/
GET    /api/v1/proyectos/{id}/
PUT    /api/v1/proyectos/{id}/
DELETE /api/v1/proyectos/{id}/
Sensores y Lecturas
httpGET  /api/v1/sensores/
POST /api/v1/readings/
GET  /api/v1/latest-readings/{proyecto_id}/
Inteligencia Artificial
httpPOST /api/ia/classify/
GET  /api/ia/analisis/
GET  /api/ia/analisis/{id}/
Contenido Académico
httpGET /api/v1/contenido-academico/
GET /api/v1/contenido-academico/{id}/
Autenticación con JWT
javascript// Obtener token
const response = await fetch('https://api.sigct-rural.com/api/auth/login/', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    username: 'usuario',
    password: 'contraseña'
  })
});

const { access, refresh } = await response.json();

// Usar token en requests
fetch('https://api.sigct-rural.com/api/v1/proyectos/', {
  headers: {
    'Authorization': `Bearer ${access}`
  }
});
```

> 📘 **Documentación completa de API**: [docs/API_REFERENCE.md](docs/API_REFERENCE.md)

---

## 🧩 Estructura del Proyecto
```
sigcTiArural/
│
├── 📁 config/                      # Configuración global
│   ├── settings.ini
│   ├── .env.example
│   └── logging.yaml
│
├── 📁 data/                        # Datos y datasets
│   ├── datasets/plantvillage/
│   ├── logs/
│   └── uploads/
│
├── 📁 docs/                        # Documentación
│   ├── MASTERDOC.md               # ⭐ Arquitectura de Software
│   ├── PLANMAESTRO.md             # ⭐ Plan de Fases
│   ├── API_REFERENCE.md
│   ├── DEPLOYMENT.md
│   ├── EDGE_SETUP.md
│   └── sena_artifacts/
│
├── 📁 src/                         # Código fuente
│   ├── 📁 backend/                 # Django Backend
│   │   ├── manage.py
│   │   ├── requirements.txt
│   │   ├── sigct_backend/
│   │   ├── users/
│   │   ├── api/
│   │   └── ia_service/
│   │
│   ├── 📁 frontend/                # React Frontend
│   │   ├── package.json
│   │   ├── vite.config.js
│   │   ├── index.html
│   │   └── src/
│   │       ├── pages/
│   │       ├── components/
│   │       ├── services/
│   │       └── hooks/
│   │
│   ├── 📁 embedded/                # Código Edge
│   │   ├── bbb_01_gateway/
│   │   ├── bbb_02_ia_edge/
│   │   ├── bbb_03_sensors/
│   │   └── shared/
│   │
│   └── 📁 ai_models/               # Modelos de IA
│       ├── notebooks/
│       ├── production_models/
│       └── scripts/
│
├── 📁 tests/                       # Pruebas
│   ├── test_backend/
│   ├── test_frontend/
│   └── test_embedded/
│
├── 📁 scripts/                     # Scripts de utilidad
│   ├── deploy_cloud.sh
│   ├── setup_bbb.sh
│   └── backup_db.sh
│
├── docker-compose.yml
├── Dockerfile
├── .gitignore
├── LICENSE
└── README.md                       # Este archivo

🧪 Testing
Backend (Django)
bashcd src/backend/

# Ejecutar todos los tests
python manage.py test

# Tests con cobertura
pip install coverage
coverage run --source='.' manage.py test
coverage report
coverage html  # Genera reporte HTML en htmlcov/

# Tests específicos
python manage.py test api.tests.test_views
python manage.py test ia_service.tests
Frontend (React)
bashcd src/frontend/

# Ejecutar tests unitarios
npm testReintentarBAContinuarbash# Tests con cobertura
npm test -- --coverage

# Tests en modo watch
npm test -- --watch

# Tests E2E con Playwright (opcional)
npm run test:e2e
Edge (Python)
bashcd src/embedded/

# Tests unitarios
python -m pytest tests/ -v

# Tests con cobertura
python -m pytest tests/ --cov=. --cov-report=html

# Test de integración MQTT
python tests/test_mqtt_integration.py
CI/CD con GitHub Actions
El proyecto incluye workflows automatizados:
yaml# .github/workflows/ci.yml
name: CI/CD Pipeline

on: [push, pull_request]

jobs:
  test-backend:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Set up Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.10'
      - name: Install dependencies
        run: |
          cd src/backend
          pip install -r requirements.txt
      - name: Run tests
        run: |
          cd src/backend
          python manage.py test

  test-frontend:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Set up Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '18'
      - name: Install dependencies
        run: |
          cd src/frontend
          npm ci
      - name: Run tests
        run: |
          cd src/frontend
          npm test -- --coverage

🚢 Despliegue
Despliegue en Render (Recomendado)
Backend

Crear cuenta en Render: https://render.com/
Crear servicio PostgreSQL:

Ir a Dashboard → New → PostgreSQL
Nombre: sigct-rural-db
Plan: Free (para desarrollo)
Guardar credenciales


Crear servicio Web:

Ir a Dashboard → New → Web Service
Conectar repositorio GitHub
Configuración:



yaml     Name: sigct-backend
     Environment: Python 3
     Build Command: pip install -r src/backend/requirements.txt
     Start Command: cd src/backend && gunicorn sigct_backend.wsgi:application --bind 0.0.0.0:$PORT
```

4. **Variables de entorno**:
```
   DEBUG=False
   SECRET_KEY=genera-una-key-segura
   DATABASE_URL=postgres://... (copiado de PostgreSQL service)
   ALLOWED_HOSTS=sigct-backend.onrender.com

Ejecutar migraciones:

En Render Dashboard → Shell



bash   python manage.py migrate
   python manage.py createsuperuser
Frontend

Crear servicio Static Site:

Dashboard → New → Static Site
Configuración:



yaml     Name: sigct-frontend
     Build Command: cd src/frontend && npm install && npm run build
     Publish Directory: src/frontend/dist
```

2. **Variables de entorno**:
```
   VITE_API_URL=https://sigct-backend.onrender.com
Despliegue con Docker (Producción)
bash# Construir imágenes
docker-compose -f docker-compose.prod.yml build

# Levantar servicios
docker-compose -f docker-compose.prod.yml up -d

# Ver logs
docker-compose -f docker-compose.prod.yml logs -f

# Ejecutar migraciones
docker-compose -f docker-compose.prod.yml exec backend python manage.py migrate

# Recolectar archivos estáticos
docker-compose -f docker-compose.prod.yml exec backend python manage.py collectstatic --noinput
Configuración de Nginx (Proxy Reverso)
nginx# /etc/nginx/sites-available/sigct-rural

server {
    listen 80;
    server_name sigct-rural.com www.sigct-rural.com;

    # Redirigir a HTTPS
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name sigct-rural.com www.sigct-rural.com;

    # Certificados SSL (Let's Encrypt)
    ssl_certificate /etc/letsencrypt/live/sigct-rural.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/sigct-rural.com/privkey.pem;

    # Frontend (React)
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }

    # Backend API (Django)
    location /api/ {
        proxy_pass http://localhost:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    # WebSocket
    location /ws/ {
        proxy_pass http://localhost:8000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }

    # Archivos estáticos
    location /static/ {
        alias /opt/sigcTiArural/src/backend/staticfiles/;
    }

    location /media/ {
        alias /opt/sigcTiArural/data/uploads/;
    }
}
```

> 📘 **Guía completa de despliegue**: [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md)

---

## 🤝 Contribuciones

¡Las contribuciones son bienvenidas! Este es un proyecto de código abierto para la comunidad.

### Cómo Contribuir

1. **Fork** el proyecto
2. Crea una **rama feature** (`git checkout -b feature/nueva-funcionalidad`)
3. **Commit** tus cambios (`git commit -m 'feat: Agrega nueva funcionalidad'`)
4. **Push** a la rama (`git push origin feature/nueva-funcionalidad`)
5. Abre un **Pull Request**

### Convenciones de Commits

Usamos [Conventional Commits](https://www.conventionalcommits.org/):
```
feat: Nueva característica
fix: Corrección de bug
docs: Cambios en documentación
style: Formato (sin cambios en código)
refactor: Refactorización
test: Agregar tests
chore: Tareas de mantenimiento
Ejemplos:
bashgit commit -m "feat(api): Agregar endpoint para análisis IA"
git commit -m "fix(dashboard): Corregir actualización en tiempo real"
git commit -m "docs(readme): Actualizar instrucciones de instalación"
```

### Código de Conducta

- ✅ Sé respetuoso y constructivo
- ✅ Documenta tu código
- ✅ Escribe tests para nuevas funcionalidades
- ✅ Sigue las guías de estilo (PEP 8 para Python, ESLint para JS)
- ❌ No uses lenguaje ofensivo
- ❌ No hagas spam de issues/PRs

### Reportar Bugs

Si encuentras un bug, por favor:

1. **Verifica** que no esté ya reportado en [Issues](https://github.com/badolgm/sigcTiArural/issues)
2. **Crea un nuevo issue** con:
   - Descripción clara del problema
   - Pasos para reproducirlo
   - Comportamiento esperado vs. actual
   - Screenshots (si aplica)
   - Entorno (OS, versión de Python/Node, etc.)

### Solicitar Features

Para proponer nuevas funcionalidades:

1. Abre un **Issue** con etiqueta `enhancement`
2. Describe el problema que resolvería
3. Propón una solución (opcional)
4. Espera feedback de la comunidad

---

## 📄 Documentación

### Documentos Principales

| Documento | Descripción |
|-----------|-------------|
| **[MASTERDOC.md](docs/MASTERDOC.md)** | 📘 Documento de Arquitectura de Software (DAS) completo con diagramas C4, E-R, casos de uso |
| **[PLANMAESTRO.md](docs/PLANMAESTRO.md)** | 🚀 Plan de fases de desarrollo con cronograma detallado |
| **[API_REFERENCE.md](docs/API_REFERENCE.md)** | 🌐 Documentación completa de endpoints REST |
| **[DEPLOYMENT.md](docs/DEPLOYMENT.md)** | 🚢 Guía paso a paso para despliegue en producción |
| **[EDGE_SETUP.md](docs/EDGE_SETUP.md)** | 🖥️ Configuración detallada de BeagleBone Black |
| **[CONTRIBUTING.md](docs/CONTRIBUTING.md)** | 🤝 Guía para contribuidores |

### Documentación Interactiva

Una vez desplegado, accede a:

- **Swagger UI**: https://api.sigct-rural.com/api/docs/
- **ReDoc**: https://api.sigct-rural.com/api/redoc/

### Tutoriales y Videos

- 📹 [Video: Instalación Completa](https://youtube.com/...)
- 📹 [Video: Configuración BeagleBone Black](https://youtube.com/...)
- 📹 [Video: Entrenar Modelo de IA](https://youtube.com/...)
- 📝 [Blog: Agricultura 4.0 con IoT](https://sigct-rural.com/blog)

---

## 🎓 Contexto Académico

### Proyecto Productivo SENA - ADSO

Este proyecto es desarrollado como **Proyecto Productivo** del programa **Tecnología en Análisis y Desarrollo de Software (ADSO)** del **SENA (Servicio Nacional de Aprendizaje)** de Colombia.

#### Competencias Demostradas

<table>
<tr>
<td width="50%">

**Técnicas**
- ✅ Desarrollo Full-Stack (React + Django)
- ✅ Diseño de APIs RESTful
- ✅ Bases de datos relacionales (PostgreSQL)
- ✅ Machine Learning aplicado (TensorFlow)
- ✅ IoT y sistemas embebidos (BeagleBone)
- ✅ Arquitectura de software (Modelo C4)
- ✅ Control de versiones (Git/GitHub)
- ✅ Despliegue en la nube (Render)

</td>
<td width="50%">

**Transversales**
- ✅ Trabajo autónomo
- ✅ Resolución de problemas complejos
- ✅ Documentación técnica
- ✅ Pensamiento sistémico
- ✅ Aprendizaje continuo
- ✅ Comunicación efectiva
- ✅ Responsabilidad social
- ✅ Innovación tecnológica

</td>
</tr>
</table>

#### Artefactos Entregables

- ✅ **Proyecto Formativo**: Documento completo del proyecto
- ✅ **Evidencias**: Screenshots, videos demostrativos
- ✅ **Código Fuente**: Repositorio GitHub completo
- ✅ **Documentación Técnica**: MASTERDOC, APIs, Despliegue
- ✅ **Presentación**: Slides para sustentación
- ✅ **Video Demo**: Demostración del sistema funcionando

### Instituciones Colaboradoras

<table>
<tr>
<td align="center" width="25%">
<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/ce/Escudo-SENA.svg/1200px-Escudo-SENA.svg.png" width="80"/><br/>
<b>SENA Colombia</b><br/>
<sub>Formación Técnica</sub>
</td>
<td align="center" width="25%">
<img src="https://plantvillage.psu.edu/assets/img/pv_logo.png" width="80"/><br/>
<b>PlantVillage</b><br/>
<sub>Dataset IA</sub>
</td>
<td align="center" width="25%">
<img src="https://www.fing.edu.uy/sites/default/files/styles/large/public/2020-01/LOGO%20FING%20HORIZONTAL%20RGB-POSITIVO.png" width="80"/><br/>
<b>EVA FING Uruguay</b><br/>
<sub>Recursos Educativos</sub>
</td>
<td align="center" width="25%">
<img src="https://www.kaggle.com/static/images/site-logo.png" width="80"/><br/>
<b>Kaggle</b><br/>
<sub>Datasets Adicionales</sub>
</td>
</tr>
</table>

---

## 📜 Licencia

Este proyecto está licenciado bajo **MIT License** - ver el archivo [LICENSE](LICENSE) para más detalles.
```
MIT License

Copyright (c) 2025 Bernardo A. Gómez Montoya

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
¿Por qué MIT?

✅ Permite uso comercial
✅ Permite modificación
✅ Permite distribución
✅ Permite uso privado
⚠️ Sin garantía


👥 Autores
Autor Principal
<table>
<tr>
<td align="center" width="150">
<img src="https://github.com/badolgm.png" width="100" style="border-radius:50%"/><br/>
<b>Bernardo A. Gómez Montoya</b><br/>
<sub>Desarrollador Full-Stack</sub><br/>
<a href="mailto:badolfogm@gmail.com">📧 Email</a> •
<a href="https://github.com/badolgm">🐙 GitHub</a><br/>
<sub>Medellín, Colombia 🇨🇴</sub>
</td>
<td>
Rol: Líder del Proyecto, Arquitecto de Software
Responsabilidades:

Diseño del proyecto completo Bernardo Gómez
Desarrollo Backend (Django)
Desarrollo Frontend (React)
Entrenamiento de modelos de IA
Configuración de hardware embebido
Documentación técnica completa

Formación: Tecnología en Análisis y Desarrollo de Software - SENA
</td>
</tr>
</table>
Asistentes y Colaboradores 

Asistente de IA para apoyo en documentación y arquitectura
-Gemini (Google AI)
-Claud
-Trae  
 
Instructores SENA: 
-Henry Torres Pertuz:  Guía y lider en revisión académica
-Comunidad Open Source: Contribuidores de GitHub


🙏 Agradecimientos
Este proyecto no sería posible sin el apoyo de:
Instituciones

SENA Colombia por la formación técnica de calidad y gratuita
PlantVillage (Penn State University) por el dataset de código abierto
EVA FING (Universidad de la República, Uruguay) por recursos educativos
Kaggle Community por datasets y tutoriales de ML

Tecnologías Open Source
Agradecemos a las comunidades de:

Django y Django REST Framework
React y Vite
TensorFlow y Keras
PostgreSQL y PostGIS
BeagleBoard.org por hardware accesible

Recursos Educativos

freeCodeCamp por tutoriales gratuitos
Stack Overflow por resolver dudas
GitHub por hosting del código
Render por hosting gratuito en la nube


📞 Contacto y Soporte
Canales de Comunicación
<table>
<tr>
<td align="center" width="25%">
<b>📧 Email</b><br/>
<a href="mailto:badolfogm@gmail.com">badolfogm@gmail.com</a>
</td>
<td align="center" width="25%">
<b>🐙 GitHub</b><br/>
<a href="https://github.com/badolgm">@badolgm</a>
</td>
<td align="center" width="25%">
<b>🐛 Issues</b><br/>
<a href="https://github.com/badolgm/sigcTiArural/issues">Reportar Bug</a>
</td>
<td align="center" width="25%">
<b>💬 Discussions</b><br/>
<a href="https://github.com/badolgm/sigcTiArural/discussions">Comunidad</a>
</td>
</tr>
</table>
Preguntas Frecuentes (FAQ)
<details>
<summary><b>¿Puedo usar este proyecto comercialmente?</b></summary>
<br/>
Sí, la licencia MIT permite uso comercial. Solo debes mantener el aviso de copyright.
</details>
<details>
<summary><b>¿Necesito exactamente 3 BeagleBone Black?</b></summary>
<br/>
No es obligatorio. Puedes adaptar el código para usar Raspberry Pi, Arduino o incluso simular los sensores. El diseño de 3 BBB es para demostración completa del clúster Edge.
</details>
<details>
<summary><b>¿Funciona con otros cultivos además de tomate y papa?</b></summary>
<br/>
El modelo actual está entrenado para 38 enfermedades de tomate, papa y pimiento. Puedes reentrenar con otros datasets (ej. trigo, maíz) siguiendo los notebooks en <code>src/ai_models/</code>.
</details>
<details>
<summary><b>¿Puedo desplegar sin BeagleBone (solo Cloud)?</b></summary>
<br/>
Sí, el sistema funciona completamente en modo Cloud-only. Simplemente ignora la parte Edge y sube imágenes manualmente al Laboratorio IA.
</details>
<details>
<summary><b>¿Cómo contribuyo si no soy programador?</b></summary>
<br/>
Puedes:
<ul>
<li>Mejorar la documentación</li>
<li>Traducir a otros idiomas</li>
<li>Reportar bugs</li>
<li>Compartir el proyecto en redes sociales</li>
<li>Crear tutoriales en video</li>
</ul>
</details>
<details>
<summary><b>¿Hay una versión móvil (app nativa)?</b></summary>
<br/>
Actualmente no, pero el frontend es responsive y funciona perfectamente en navegadores móviles. Una app nativa está en el roadmap futuro.
</details>

🗺️ Roadmap Futuro
Versión 5.0 (2026 Q2)

 App móvil nativa (React Native)
 Integración con SofiaPlus (SENA)
 Soporte para más cultivos (trigo, café, maíz)
 Dashboard con realidad aumentada (AR)
 Predicción de cosecha con ML
 Marketplace de sensores compatibles

Versión 6.0 (2026 Q4)

 Multi-idioma (inglés, portugués)
 Blockchain para trazabilidad de cultivos
 IA conversacional (chatbot agrónomo)
 Red mesh de nodos IoT
 Integración con drones


📊 Estadísticas del Proyecto
<div align="center">
Mostrar imagen
Mostrar imagen
Mostrar imagen
Mostrar imagen
Mostrar imagen
Mostrar imagen
Mostrar imagen
</div>

<div align="center">
🌱 "La educación tecnológica aplicada es el camino más corto entre la idea y la innovación."
— Proyecto SIGC&TRural

Si este proyecto te inspira, ¡apóyalo! ⭐
Mostrar imagen
Mostrar imagen
Mostrar imagen

Links Rápidos
🏠 Inicio •
📚 Documentación •
🚀 Instalación •
🤖 IA •
🌐 API •
🤝 Contribuir •
📄 Licencia

Hecho con ❤️ en Colombia 🇨🇴
Para la comunidad rural y educativa del mundo 🌍
© 2025 Bernardo A. Gómez Montoya | Proyecto SIGC&T Rural | MIT License

<sub>Última actualización: 02 de Noviembre, 2025 | Versión 4.2</sub>
</div>

🎉 ¡Gracias por visitar SIGC&T Rural!
¿Listo para comenzar? → ⚡ Inicio Rápido
¿Tienes preguntas? → 💬 Abre un Discussion
¿Encontraste un bug? → 🐛 Reporta un Issue
¿Quieres contribuir? → 🤝 Lee la Guía de Contribución

¡Juntos podemos transformar la agricultura con tecnología! 🚜💻🌾